class CustomLoader:
    def load_data(self):
        raise NotImplementedError ("Subclasses should implement this method")
